library(readxl)

rm(list=ls())


data <- read_xlsx("dataForRegression.xlsx")

reg <- lm(`Avg Inspection Score`~.-data$`Avg Inspection Score`, data = data)

reg$coefficients
summary(reg)
